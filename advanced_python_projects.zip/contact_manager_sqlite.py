
import sqlite3
import csv
import os

DB_NAME = "contacts.db"

def init_db():
    conn = sqlite3.connect(DB_NAME)
    cur = conn.cursor()
    cur.execute(
        '''CREATE TABLE IF NOT EXISTS contacts (
               id INTEGER PRIMARY KEY AUTOINCREMENT,
               name TEXT NOT NULL,
               phone TEXT,
               email TEXT
           )'''
    )
    conn.commit()
    conn.close()

def add_contact(name, phone, email):
    conn = sqlite3.connect(DB_NAME)
    cur = conn.cursor()
    cur.execute('INSERT INTO contacts (name, phone, email) VALUES (?, ?, ?)', (name, phone, email))
    conn.commit()
    conn.close()
    print("✅ Contact added.")

def list_contacts():
    conn = sqlite3.connect(DB_NAME)
    cur = conn.cursor()
    cur.execute('SELECT id, name, phone, email FROM contacts ORDER BY id')
    rows = cur.fetchall()
    conn.close()
    if not rows:
        print("No contacts yet.")
    else:
        print("\nID  | Name                | Phone           | Email")
        print("-"*60)
        for r in rows:
            print(f"{r[0]:<3} | {r[1]:<19} | {r[2] or '':<15} | {r[3] or ''}")
        print()

def search_contacts(query):
    conn = sqlite3.connect(DB_NAME)
    cur = conn.cursor()
    like = f"%{query}%"
    cur.execute('SELECT id, name, phone, email FROM contacts WHERE name LIKE ? OR phone LIKE ? OR email LIKE ?', (like, like, like))
    rows = cur.fetchall()
    conn.close()
    if not rows:
        print("No match found.")
    else:
        for r in rows:
            print(f"{r[0]}: {r[1]} | {r[2] or ''} | {r[3] or ''}")

def update_contact(cid, name=None, phone=None, email=None):
    conn = sqlite3.connect(DB_NAME)
    cur = conn.cursor()
    cur.execute('SELECT id, name, phone, email FROM contacts WHERE id=?', (cid,))
    row = cur.fetchone()
    if not row:
        print("❌ Contact not found.")
        conn.close()
        return
    new_name = name if name is not None else row[1]
    new_phone = phone if phone is not None else row[2]
    new_email = email if email is not None else row[3]
    cur.execute('UPDATE contacts SET name=?, phone=?, email=? WHERE id=?', (new_name, new_phone, new_email, cid))
    conn.commit()
    conn.close()
    print("✅ Contact updated.")

def delete_contact(cid):
    conn = sqlite3.connect(DB_NAME)
    cur = conn.cursor()
    cur.execute('DELETE FROM contacts WHERE id=?', (cid,))
    conn.commit()
    conn.close()
    print("🗑️  Contact deleted.")

def export_csv(filename="contacts_export.csv"):
    conn = sqlite3.connect(DB_NAME)
    cur = conn.cursor()
    cur.execute('SELECT id, name, phone, email FROM contacts ORDER BY id')
    rows = cur.fetchall()
    conn.close()
    with open(filename, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["id", "name", "phone", "email"])
        writer.writerows(rows)
    print(f"📁 Exported to {filename}")

def menu():
    print("""\n=== Contact Manager (SQLite) ===
1) Add contact
2) List contacts
3) Search contacts
4) Update contact
5) Delete contact
6) Export CSV
0) Exit
""" )

def main():
    init_db()
    while True:
        menu()
        choice = input("Choose: ").strip()
        if choice == "1":
            name = input("Name: ").strip()
            phone = input("Phone: ").strip()
            email = input("Email: ").strip()
            add_contact(name, phone, email)
        elif choice == "2":
            list_contacts()
        elif choice == "3":
            q = input("Search text: ").strip()
            search_contacts(q)
        elif choice == "4":
            try:
                cid = int(input("ID to update: ").strip())
            except ValueError:
                print("Enter a valid numeric ID.")
                continue
            name = input("New name (leave blank to keep): ").strip()
            phone = input("New phone (leave blank to keep): ").strip()
            email = input("New email (leave blank to keep): ").strip()
            update_contact(cid, name if name else None, phone if phone else None, email if email else None)
        elif choice == "5":
            try:
                cid = int(input("ID to delete: ").strip())
            except ValueError:
                print("Enter a valid numeric ID.")
                continue
            delete_contact(cid)
        elif choice == "6":
            filename = input("CSV filename (default contacts_export.csv): ").strip() or "contacts_export.csv"
            export_csv(filename)
        elif choice == "0":
            print("Bye!")
            break
        else:
            print("Invalid choice. Try again.")

if __name__ == "__main__":
    main()
