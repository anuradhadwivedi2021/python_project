
import os
import sqlite3
import json
from tkinter import Tk, Label, Entry, Button, StringVar, ttk, END, messagebox
from tkinter import simpledialog
from cryptography.fernet import Fernet
import secrets
import string

DB_NAME = "vault.db"
KEY_FILE = "key.key"

def load_key():
    if not os.path.exists(KEY_FILE):
        key = Fernet.generate_key()
        with open(KEY_FILE, "wb") as f:
            f.write(key)
    else:
        with open(KEY_FILE, "rb") as f:
            key = f.read()
    return key

def get_cipher():
    return Fernet(load_key())

def init_db():
    conn = sqlite3.connect(DB_NAME)
    cur = conn.cursor()
    cur.execute('''CREATE TABLE IF NOT EXISTS entries (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        site TEXT NOT NULL,
        username TEXT NOT NULL,
        secret BLOB NOT NULL
    )''')
    conn.commit()
    conn.close()

def encrypt_password(password: str) -> bytes:
    cipher = get_cipher()
    return cipher.encrypt(password.encode("utf-8"))

def decrypt_password(token: bytes) -> str:
    cipher = get_cipher()
    return cipher.decrypt(token).decode("utf-8")

def save_entry(site, username, password):
    conn = sqlite3.connect(DB_NAME)
    cur = conn.cursor()
    blob = encrypt_password(password)
    cur.execute('INSERT INTO entries (site, username, secret) VALUES (?, ?, ?)', (site, username, blob))
    conn.commit()
    conn.close()

def read_entries():
    conn = sqlite3.connect(DB_NAME)
    cur = conn.cursor()
    cur.execute('SELECT id, site, username, secret FROM entries ORDER BY id DESC')
    rows = cur.fetchall()
    conn.close()
    return rows

def delete_entry(entry_id):
    conn = sqlite3.connect(DB_NAME)
    cur = conn.cursor()
    cur.execute('DELETE FROM entries WHERE id=?', (entry_id,))
    conn.commit()
    conn.close()

def generate_password(length=16, use_symbols=True):
    alphabet = string.ascii_letters + string.digits
    if use_symbols:
        alphabet += string.punctuation
    return ''.join(secrets.choice(alphabet) for _ in range(length))

class App:
    def __init__(self, root):
        root.title("Password Manager (Encrypted)")
        root.geometry("720x480")

        Label(root, text="Site").grid(row=0, column=0, padx=8, pady=6, sticky="e")
        Label(root, text="Username").grid(row=1, column=0, padx=8, pady=6, sticky="e")
        Label(root, text="Password").grid(row=2, column=0, padx=8, pady=6, sticky="e")

        self.site = StringVar()
        self.username = StringVar()
        self.password = StringVar()

        Entry(root, textvariable=self.site, width=40).grid(row=0, column=1, padx=8, pady=6, sticky="w")
        Entry(root, textvariable=self.username, width=40).grid(row=1, column=1, padx=8, pady=6, sticky="w")
        Entry(root, textvariable=self.password, show="*", width=40).grid(row=2, column=1, padx=8, pady=6, sticky="w")

        Button(root, text="Generate", command=self.on_generate).grid(row=2, column=2, padx=6, pady=6)
        Button(root, text="Save", command=self.on_save).grid(row=3, column=1, padx=6, pady=6, sticky="w")

        self.tree = ttk.Treeview(root, columns=("id", "site", "username", "password"), show="headings")
        self.tree.heading("id", text="ID")
        self.tree.heading("site", text="Site")
        self.tree.heading("username", text="Username")
        self.tree.heading("password", text="Password (click to reveal)")
        self.tree.column("id", width=40)
        self.tree.column("site", width=200)
        self.tree.column("username", width=200)
        self.tree.column("password", width=220)
        self.tree.grid(row=4, column=0, columnspan=3, padx=8, pady=8, sticky="nsew")

        root.grid_rowconfigure(4, weight=1)
        root.grid_columnconfigure(1, weight=1)

        Button(root, text="Refresh", command=self.load_data).grid(row=5, column=0, padx=6, pady=6, sticky="w")
        Button(root, text="Delete Selected", command=self.on_delete).grid(row=5, column=1, padx=6, pady=6, sticky="w")

        self.tree.bind("<Double-1>", self.on_double_click)

        init_db()
        self.load_data()

    def on_generate(self):
        length = simpledialog.askinteger("Generate", "Password length?", minvalue=8, initialvalue=16)
        if not length:
            return
        pwd = generate_password(length=length, use_symbols=True)
        self.password.set(pwd)

    def on_save(self):
        site = self.site.get().strip()
        username = self.username.get().strip()
        pwd = self.password.get().strip()
        if not site or not username or not pwd:
            messagebox.showerror("Error", "All fields are required.")
            return
        save_entry(site, username, pwd)
        messagebox.showinfo("Saved", "Entry saved securely.")
        self.site.set(""); self.username.set(""); self.password.set("")
        self.load_data()

    def load_data(self):
        for i in self.tree.get_children():
            self.tree.delete(i)
        for eid, site, user, secret in read_entries():
            self.tree.insert("", "end", values=(eid, site, user, "•••••••"))

    def on_double_click(self, event):
        item = self.tree.selection()
        if not item:
            return
        values = self.tree.item(item, "values")
        eid = values[0]
        # Fetch row again to decrypt
        rows = read_entries()
        for rid, site, user, secret in rows:
            if str(rid) == str(eid):
                try:
                    pwd = decrypt_password(secret)
                except Exception as e:
                    messagebox.showerror("Error", f"Cannot decrypt: {e}")
                    return
                messagebox.showinfo("Password", f"Site: {site}\nUser: {user}\nPassword: {pwd}")
                break

    def on_delete(self):
        item = self.tree.selection()
        if not item:
            return
        values = self.tree.item(item, "values")
        eid = values[0]
        if messagebox.askyesno("Confirm", "Delete selected entry?"):
            delete_entry(int(eid))
            self.load_data()

if __name__ == "__main__":
    try:
        from cryptography.fernet import Fernet  # noqa
    except Exception as e:
        print("This app requires 'cryptography'. Install it with:")
        print("    pip install cryptography")
        raise
    root = Tk()
    App(root)
    root.mainloop()
